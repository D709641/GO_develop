package main

import (
	"encoding/json"

	"github.com/gofiber/fiber"
)

type FruitInterface struct {
	Page   int
	Fruits []string
}

func main() {
	app := fiber.New()

	app.Get("/", func(c *fiber.Ctx) {
		c.Send("Hello, Fiber!")
	})

	app.Static("/public", "./public")

	app.Get("/hello", func(c *fiber.Ctx) {
		if err := c.SendFile("./templates/hello.html"); err != nil {
			c.Next(err)
		}
	})

	app.Get("/parameter/:value", func(c *fiber.Ctx) {
		c.Send("Get request with value: " + c.Params("value"))
	})

	app.Get("/api/*", func(c *fiber.Ctx) {
		c.Send("API path: " + c.Params("*") + " -> do lookups with these values")

		if c.Params("*") == "fruits" {

			response := FruitInterface{
				Page:   1,
				Fruits: []string{"apple", "peach", "pear"},
			}

			responseJson, _ := json.Marshal(response)

			c.Send(responseJson)

		}
	})

	app.Listen(3000)
}
